interface MovieDetails {
    title: string;
    tmdb: string;
    imdb: string;
    year: string;
    quality: string;
    version: string;
    poster: string;
    link: string;
  }