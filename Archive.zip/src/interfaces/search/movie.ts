interface Movie {
    Title: string;
    Year: string;
    imdbID: string;
    Poster: string;
  }